/* This file belongs to: "conveex" (Ha Juegos Copyright 2022), Any unauthorized modification or change will be penalized, more information to authorize your copies you can contact me on discord: https://discord.gg/p6a7tqVJxn
GitHubs: https://github.com/CibNumeritos https://github.com/conveex
 *********************************************************************
Este archivo pertenece a: "conveex" (Ha Juegos Copyright 2022), Cualquier modificación o cambio no autorizado será sancionado, más información para autorizar tus copias puedes contactar conmigo en discord: https://discord.gg/p6a7tqVJxn
Sus GitHubs: https://github.com/conveex */
import{world}
from"mojang-minecraft"
world.events.beforeItemUse.subscribe(usingItem=>{const players=usingItem.source
const item=usingItem.item
if(players.id=='minecraft:player'){let player=Array.from(world.getPlayers()).find(plr=>plr.name==players.name)
if(item.id=='minecraft:carrot_on_a_stick'||item.id=='minecraft:warped_fungus_on_a_stick'||item.id=='minecraft:shears'){player.runCommand(`function System_commands/by_using_tool_possibility`)}}})
world.events.blockBreak.subscribe(eventBreakMine=>{const players=eventBreakMine.player
let player=Array.from(world.getPlayers()).find(p=>p.name==players.name)
player.runCommand(`function System_commands/by_using_tool_possibility`)})
world.events.entityHit.subscribe(eventBreakHit=>{try{const players=eventBreakHit.entity
const block=eventBreakHit.hitBlock
const damaged=eventBreakHit.hitEntity
if(players.id=='minecraft:player'&&block==null){let player=Array.from(world.getPlayers()).find(plr=>plr.name==players.name)
player.runCommand(`function System_commands/by_using_tool_possibility`)}else if(damaged.id=='minecraft:player'){let damagedp=Array.from(world.getPlayers()).find(plr=>plr.name==damaged.name)
if(damagedp.isSneaking==true){if(runCommand(`execute "${damagedp.name}" ~ ~ ~ testfor @s[hasitem={item=shield,location=slot.weapon.offhand}]`).error==false){damagedp.runCommand(`function System_commands/by_using_shield_possibility`)
damagedp.addTag('offhand_s')}else if(runCommand(`execute "${damagedp.name}" ~ ~ ~ testfor @s[hasitem={item=shield,location=slot.weapon.mainhand}]`).error==false){damagedp.runCommand(`function System_commands/by_using_shield_possibility`)
damagedp.addTag('mainhand_s')}}}}catch{}})
world.events.entityHurt.subscribe(eventHurt=>{const players=eventHurt.hurtEntity
const cause=eventHurt.cause
const origin=eventHurt.damagingEntity
if(players.id=='minecraft:player'){let player=Array.from(world.getPlayers()).find(plr=>plr.name==players.name)
if(runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=chainmail_chestplate,location=slot.armor.chest}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=chainmail_boots,location=slot.armor.feet}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=chainmail_leggings,location=slot.armor.legs}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=chainmail_helmet,location=slot.armor.head}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=leather_chestplate,location=slot.armor.chest}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=leather_boots,location=slot.armor.feet}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=leather_leggings,location=slot.armor.legs}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=leather_helmet,location=slot.armor.head}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=iron_chestplate,location=slot.armor.chest}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=iron_boots,location=slot.armor.feet}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=iron_leggings,location=slot.armor.legs}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=iron_helmet,location=slot.armor.head}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=golden_chestplate,location=slot.armor.chest}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=golden_boots,location=slot.armor.feet}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=golden_leggings,location=slot.armor.legs}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=golden_helmet,location=slot.armor.head}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=diamond_chestplate,location=slot.armor.chest}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=diamond_boots,location=slot.armor.feet}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=diamond_leggings,location=slot.armor.legs}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=diamond_helmet,location=slot.armor.head}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=netherite_chestplate,location=slot.armor.chest}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=netherite_boots,location=slot.armor.feet}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=netherite_leggings,location=slot.armor.legs}]`).error==false||runCommand(`execute "${player.name}" ~ ~ ~ testfor @s[hasitem={item=netherite_helmet,location=slot.armor.head}]`).error==false){player.runCommand(`function System_commands/by_damage_armor_possibility`)}}})
world.events.itemStopCharge.subscribe(eventSItems=>{const players=eventSItems.source
const items=eventSItems.itemStack
if(players.id=='minecraft:player'){if(items.id=='minecraft:bow'||items.id=='minecraft:crossbow'||items.id=='minecraft:fishing_rod'){let player=Array.from(world.getPlayers()).find(plr=>plr.name==players.name)
player.runCommand(`function System_commands/by_using_tool_possibility`)}}})
world.events.itemReleaseCharge.subscribe(eventCItems=>{const players=eventCItems.source
const items=eventCItems.itemStack
const duration=eventCItems.useDuration
if(items.id=='minecraft:trident'){let player=Array.from(world.getPlayers()).find(plr=>plr.name==players.name)
player.runCommand(`function System_commands/by_using_tool_possibility`)}})
world.events.itemUseOn.subscribe(eventItem=>{const players=eventItem.source
const item=eventItem.item
if(players.id=='minecraft:player'){let player=Array.from(world.getPlayers()).find(plr=>plr.name==players.name)
if(item.id=='minecraft:flint_and_steel'){player.runCommand(`function System_commands/by_using_tool_possibility`)}else if(item.id=='minecraft:shears'){player.runCommand(`function System_commands/by_using_tool_possibility`)}}})
function runCommand(command){try{return{error:false,...world.getDimension("overworld").runCommand(command)}}catch(error){return{error:true}}}
/* This file belongs to: "conveex" (Ha Juegos Copyright 2022), Any unauthorized modification or change will be penalized, more information to authorize your copies you can contact me on discord: https://discord.gg/p6a7tqVJxn
GitHubs: https://github.com/CibNumeritos https://github.com/conveex
 *********************************************************************
Este archivo pertenece a: "conveex" (Ha Juegos Copyright 2022), Cualquier modificación o cambio no autorizado será sancionado, más información para autorizar tus copias puedes contactar conmigo en discord: https://discord.gg/p6a7tqVJxn
Sus GitHubs: https://github.com/conveex */